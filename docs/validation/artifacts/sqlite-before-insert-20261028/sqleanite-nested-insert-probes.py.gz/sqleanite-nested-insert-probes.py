import sys,unittest
sys.path.insert(0,'/dev/shm/sqleanite-catalog-20261026/scripts')
from test_check_add_column import case
from test_trigger_execution import SETUP,TAIL
class NestedInsert(unittest.TestCase):pass
Q={
 'mixed_key':"CREATE TRIGGER b BEFORE INSERT ON t BEGIN UPDATE log SET n=n+1;END;CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t VALUES((SELECT max(id) FROM t)+total_changes()+10,new.v,4);END;UPDATE log SET v='d';"+TAIL,
 'discard_ordinary':"CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t(id,v,n,n) VALUES(4,(SELECT new.v),4,abs(-9223372036854775808));END;UPDATE log SET v='d';"+TAIL,
 'discard_rowid':"CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t(id,rowid,v,n) VALUES(abs(-9223372036854775808),(SELECT 4),new.v,4);END;UPDATE log SET v='d';"+TAIL,
 'multi_materialized':"CREATE TRIGGER b BEFORE INSERT ON t BEGIN UPDATE log SET n=n+1;END;CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t VALUES(4,(SELECT new.v),total_changes()),(5,(SELECT new.v),total_changes());END;UPDATE log SET v='d';"+TAIL,
 'captured_subtype':"CREATE TRIGGER b BEFORE INSERT ON t BEGIN UPDATE log SET n=subtype(new.v);END;CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t VALUES(4,(SELECT json('[1]')),4);END;UPDATE log SET v='d';"+TAIL,
 'direct_tag_with_capture':"CREATE TRIGGER b BEFORE INSERT ON t BEGIN UPDATE log SET n=subtype(new.v);END;CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t VALUES((SELECT 4),json('[1]'),4);END;UPDATE log SET v='d';"+TAIL,
 'scalar_after_mutation':"CREATE TRIGGER b BEFORE INSERT ON t BEGIN DELETE FROM t WHERE id=3;END;CREATE TRIGGER a AFTER UPDATE ON log BEGIN INSERT INTO t VALUES((SELECT max(id)+10 FROM t),new.v,4);END;UPDATE log SET v='d';"+TAIL,
}
for name,q in Q.items():
 for suffix,mode in [('rollback','--verified-file'),('wal','--verified-wal-file')]:setattr(NestedInsert,'test_'+name+'_'+suffix,case(q,mode,SETUP))
unittest.main()
