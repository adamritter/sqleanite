import os,sys,subprocess,json,re
sys.path.insert(0,'scripts')
from test_check_add_column import statement_lines
from test_pragma_tables import SQLITE,ROOT
binary=str(ROOT/'.lake/build/bin/sqleanite_tests')
errors=lambda text:[re.sub(r'^(?:Parse error|Runtime error|Error)(?: near line [0-9]+)?: ?','',line) for line in text.splitlines() if re.match(r'^(?:Parse error|Runtime error|Error)(?: near line [0-9]+)?:',line)]
cases=[]
for unique in ['',',v UNIQUE']:
 for trigger in [False,True]:
  setup='CREATE TABLE p(id INTEGER PRIMARY KEY);INSERT INTO p VALUES(1);CREATE TABLE c(id INTEGER PRIMARY KEY,pid INTEGER DEFAULT 99 REFERENCES p(id)'+unique+');INSERT INTO c(id,pid) VALUES(10,1);PRAGMA foreign_keys=ON;'
  if trigger:setup+='CREATE TRIGGER a AFTER INSERT ON c BEGIN SELECT new.id;END;'
  for policy in ['',' OR REPLACE',' OR IGNORE',' OR ABORT']:
   for inputs in ['(id,pid) VALUES(4,99)','(id,pid) VALUES(NULL,99)','(pid) VALUES(99)',' DEFAULT VALUES','(id,pid) SELECT 4,99','(id,pid) VALUES(4,1),(5,99)']:
    cases.append((f'child_{bool(unique)}_{trigger}_{policy}_{inputs}',setup+f'INSERT{policy} INTO c'+inputs+';SELECT changes(),total_changes(),last_insert_rowid();SELECT * FROM c ORDER BY id;'))
for trigger in [False,True]:
 for policy in ['',' OR REPLACE',' OR IGNORE',' OR ABORT']:
  for inputs in ['VALUES(4,99)','VALUES(4,4)','(pid) VALUES(99)','SELECT 4,99','VALUES(4,1),(5,99)']:
   setup='CREATE TABLE p(id INTEGER PRIMARY KEY,pid INTEGER REFERENCES p(id));INSERT INTO p VALUES(1,4);'
   if trigger:setup+='CREATE TRIGGER a AFTER INSERT ON p BEGIN SELECT new.id;END;'
   cases.append((f'self_{trigger}_{policy}_{inputs}',setup+'PRAGMA foreign_keys=ON;'+f'INSERT{policy} INTO p '+inputs+';SELECT changes(),total_changes(),last_insert_rowid();SELECT * FROM p ORDER BY id;'))
results=[]
for name,source in cases:
 script=statement_lines(source)
 a=subprocess.run([binary,'--error-effects-script'],input=script,text=True,capture_output=True,timeout=30)
 b=subprocess.run([SQLITE,'-batch',':memory:'],input=script,text=True,capture_output=True,timeout=30)
 av={'code':a.returncode,'stdout':a.stdout,'errors':errors(a.stderr)};bv={'code':b.returncode,'stdout':b.stdout,'errors':errors(b.stderr)}
 results.append(dict(name=name,source=source,lean=av,native=bv,matched=av==bv))
report=dict(cases=len(cases),failures=sum(not x['matched'] for x in results),results=results)
open('/tmp/sqleanite-fk-expansion-probes.json','w').write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':report['cases'],'failures':report['failures'],'differences':[r for r in results if not r['matched']]}))
