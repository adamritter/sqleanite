import SQLeanite.CoreCatalogData
open SQLeanite
#eval (CoreTokenGrammar.parseCertified "CREATE INDEX \"ix\" ON \"t\"(\"value\") /*LSQL:TEXT*/").map (fun p => repr p.statements)
