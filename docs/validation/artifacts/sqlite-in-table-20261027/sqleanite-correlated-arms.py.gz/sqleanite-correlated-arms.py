import sys,unittest
sys.path.insert(0,'scripts')
from test_pragma_tables import case
from test_subquery_sets import SETUP
class Arms(unittest.TestCase):pass
queries={
 'scalar_union_all':'SELECT id,(SELECT 0 UNION ALL SELECT t.n) FROM t ORDER BY id;',
 'scalar_union':'SELECT id,(SELECT t.n UNION SELECT -1) FROM t ORDER BY id;',
 'scalar_except':'SELECT id,(SELECT t.n EXCEPT SELECT 1) FROM t ORDER BY id;',
 'scalar_intersect':'SELECT id,(SELECT t.n INTERSECT SELECT 1) FROM t ORDER BY id;',
 'scalar_offset':'SELECT id,(SELECT 0 UNION ALL SELECT t.n LIMIT 1 OFFSET 1) FROM t ORDER BY id;',
 'in_union':'SELECT id,n IN (SELECT -1 UNION SELECT t.n) FROM t ORDER BY id;',
 'in_except':'SELECT id,n IN (SELECT t.n EXCEPT SELECT 1) FROM t ORDER BY id;',
 'in_intersect':'SELECT id,n IN (SELECT t.n INTERSECT SELECT 1) FROM t ORDER BY id;',
 'exists_union':'SELECT id,EXISTS(SELECT 0 WHERE 0 UNION SELECT t.n WHERE t.n>0) FROM t ORDER BY id;',
 'exists_except':'SELECT id,EXISTS(SELECT t.n EXCEPT SELECT 1) FROM t ORDER BY id;',
 'exists_intersect':'SELECT id,EXISTS(SELECT t.n INTERSECT SELECT 1) FROM t ORDER BY id;',
 'arm_shadow':'SELECT id,n IN (SELECT -1 UNION SELECT n FROM u) FROM t ORDER BY id;',
 'arm_local_correlated':'SELECT id,n IN (SELECT -1 UNION SELECT n FROM u WHERE u.n=t.n) FROM t ORDER BY id;',
 'qualified_scalar':'SELECT (SELECT n FROM main.t ORDER BY id);',
 'qualified_set':'SELECT 1 IN (SELECT n FROM main.t);',
 'qualified_exists':'SELECT EXISTS(SELECT n FROM main.t);',
}
for name,sql in queries.items():
 for suffix,mode in [('rollback','--verified-file'),('wal','--verified-wal-file')]:
  setattr(Arms,'test_'+name+'_'+suffix,case(sql,mode,SETUP))
if __name__=='__main__':unittest.main()
