import sys,unittest
sys.path.insert(0,'scripts')
from test_pragma_tables import case
from test_subquery_sets import SETUP
class JoinArms(unittest.TestCase):pass
queries={
 'scalar_join_arm':'SELECT (SELECT 0 UNION ALL SELECT u.n FROM u JOIN t ON t.n=u.n);',
 'in_join_arm':'SELECT 1 IN (SELECT 0 UNION ALL SELECT u.n FROM u JOIN t ON t.n=u.n);',
 'in_correlated_join_arm':'SELECT id,n IN (SELECT 0 UNION ALL SELECT u.n FROM u JOIN t x ON x.n=u.n WHERE x.id=t.id) FROM t ORDER BY id;',
 'local_ambiguous':'SELECT id,1 IN (SELECT 0 UNION ALL SELECT n FROM u JOIN t x ON x.n=u.n) FROM t ORDER BY id;',
 'using_join_arm':'SELECT id,n IN (SELECT 0 UNION ALL SELECT n FROM u JOIN t x USING(n) WHERE x.id=t.id) FROM t ORDER BY id;',
}
for name,sql in queries.items():
 for suffix,mode in [('rollback','--verified-file'),('wal','--verified-wal-file')]:
  setattr(JoinArms,'test_'+name+'_'+suffix,case(sql,mode,SETUP))
if __name__=='__main__':unittest.main()
