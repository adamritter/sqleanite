import sys,subprocess,re,json
sys.path.insert(0,'scripts')
from test_check_add_column import statement_lines
from test_pragma_tables import SQLITE,ROOT
setup='CREATE TABLE t(id INTEGER PRIMARY KEY,n);INSERT INTO t VALUES(10,1);'
qs={
 'values_later_error':'INSERT INTO t VALUES(11,2),(12,abs(-9223372036854775808));',
 'values_later_unique':'INSERT INTO t VALUES(11,2),(10,3);',
 'select_later_error':'INSERT INTO t SELECT * FROM(VALUES(11,2),(12,abs(-9223372036854775808)));',
 'select_later_unique':'INSERT INTO t SELECT * FROM(VALUES(11,2),(10,3));',
 'values_counters':'INSERT INTO t(n) VALUES(last_insert_rowid()),(last_insert_rowid());',
 'select_counters':'INSERT INTO t(n) SELECT * FROM(VALUES(last_insert_rowid()),(last_insert_rowid()));',
 'select_rt_counters':'INSERT INTO t(n) SELECT * FROM(VALUES(last_insert_rowid()),(last_insert_rowid())) RETURNING id;',
}
results=[]
for name,q in qs.items():
 sql=statement_lines(setup+q+'SELECT changes(),total_changes(),last_insert_rowid();SELECT * FROM t ORDER BY id;')
 a=subprocess.run([str(ROOT/'.lake/build/bin/sqleanite_tests'),'--error-effects-script'],input=sql,text=True,capture_output=True)
 b=subprocess.run([SQLITE,'-batch',':memory:'],input=sql,text=True,capture_output=True)
 r=dict(name=name,sql=sql,lean=dict(code=a.returncode,stdout=a.stdout,stderr=a.stderr),native=dict(code=b.returncode,stdout=b.stdout,stderr=b.stderr));r['matched']=(a.returncode,a.stdout)==(b.returncode,b.stdout);results.append(r)
report=dict(cases=len(results),failures=sum(not r['matched'] for r in results),results=results)
open('/tmp/sqleanite-multi-error-baseline.json','w').write(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
