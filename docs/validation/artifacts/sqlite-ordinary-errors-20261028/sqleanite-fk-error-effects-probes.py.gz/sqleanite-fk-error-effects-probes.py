import sys,unittest
sys.path.insert(0,'/dev/shm/sqleanite-catalog-20261026/scripts')
from test_error_effects import case,TAIL
class ForeignErrors(unittest.TestCase):pass
SETUP='CREATE TABLE p(id INTEGER PRIMARY KEY);INSERT INTO p VALUES(1);CREATE TABLE c(id INTEGER PRIMARY KEY,pid INTEGER REFERENCES p(id));PRAGMA foreign_keys=ON;'
Q={
 'single':SETUP+'INSERT INTO c VALUES(4,99);'+TAIL+'SELECT * FROM c;',
 'returning':SETUP+'INSERT INTO c VALUES(4,99) RETURNING id;'+TAIL+'SELECT * FROM c;',
 'multiple':SETUP+'INSERT INTO c VALUES(4,1),(5,99);'+TAIL+'SELECT * FROM c;',
 'with_program':SETUP+'CREATE TRIGGER a AFTER INSERT ON c BEGIN SELECT new.id;END;INSERT INTO c VALUES(4,99);'+TAIL+'SELECT * FROM c;',
}
for name,q in Q.items():setattr(ForeignErrors,'test_'+name,case(q))
unittest.main()
