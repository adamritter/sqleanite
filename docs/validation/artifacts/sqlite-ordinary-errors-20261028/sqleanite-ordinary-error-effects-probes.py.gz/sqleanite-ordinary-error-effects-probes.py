import sys,unittest
sys.path.insert(0,'/dev/shm/sqleanite-catalog-20261026/scripts')
from test_error_effects import case,TAIL
class OrdinaryErrors(unittest.TestCase):pass
Q={
 'ordinary_constraint':"INSERT INTO t VALUES(1,'duplicate',4);"+TAIL,
 'ordinary_returning':"INSERT INTO t VALUES(4,'d',4) RETURNING abs(-9223372036854775808);"+TAIL,
}
for name,q in Q.items():setattr(OrdinaryErrors,'test_'+name,case(q))
unittest.main()
