import SQLeanite.CoreTokenGrammar
open SQLeanite
#eval (CoreTokenGrammar.parseCertified "UPDATE main.t SET n=8 WHERE id=1;").map (fun p => reprStr p.statements)
#eval (CoreTokenGrammar.parseCertified "CREATE INDEX main.pi ON t(n) WHERE n>0;").map (fun p => reprStr p.statements)
#eval (CoreTokenGrammar.parseCertified "DROP INDEX main.pi;").map (fun p => reprStr p.statements)
#eval (CoreTokenGrammar.parseCertified "DROP INDEX 'main.pi';").map (fun p => reprStr p.statements)
