import sys,subprocess,json,re
sys.path.insert(0,'scripts')
from test_check_add_column import statement_lines
from test_pragma_tables import SQLITE,ROOT
setup='CREATE TABLE src(id INTEGER PRIMARY KEY,n);INSERT INTO src VALUES(1,1),(2,2),(3,3);CREATE TABLE t(id INTEGER PRIMARY KEY,n);INSERT INTO t VALUES(10,10);'
queries={
 'table_counter':'SELECT NULL,last_insert_rowid() FROM src',
 'table_later_error':'SELECT id+10,CASE WHEN n=2 THEN abs(-9223372036854775808) ELSE n END FROM src',
 'where_counter':'SELECT NULL,n FROM src WHERE last_insert_rowid()<12',
 'rowid_order_counter':'SELECT NULL,last_insert_rowid() FROM src ORDER BY id',
 'sort_counter':'SELECT NULL,last_insert_rowid() FROM src ORDER BY n DESC',
 'sort_error':'SELECT id+10,CASE WHEN n=2 THEN abs(-9223372036854775808) ELSE n END FROM src ORDER BY n DESC',
 'self_counter':'SELECT NULL,last_insert_rowid() FROM t',
 'limit_counter':'SELECT NULL,last_insert_rowid() FROM src LIMIT 2 OFFSET 1',
 'distinct_counter':'SELECT DISTINCT NULL,last_insert_rowid() FROM src',
 'union_counter':'SELECT NULL,last_insert_rowid() UNION ALL SELECT NULL,last_insert_rowid()',
 'values_counter':'SELECT NULL,column1 FROM(VALUES(last_insert_rowid()),(last_insert_rowid()))',
 'subquery_counter':'SELECT NULL,last_insert_rowid() FROM(SELECT * FROM src)',
}
errors=lambda output:[re.sub(r'^(?:Parse error|Runtime error|Error)(?: near line [0-9]+)?: ?','',line) for line in output.splitlines() if re.match(r'^(?:Parse error|Runtime error|Error)(?: near line [0-9]+)?:',line)]
results=[]
for name,q in queries.items():
 sql=statement_lines(setup+'INSERT INTO t '+q+';SELECT changes(),total_changes(),last_insert_rowid();SELECT * FROM t ORDER BY id;')
 a=subprocess.run([str(ROOT/'.lake/build/bin/sqleanite_tests'),'--error-effects-script'],input=sql,text=True,capture_output=True);b=subprocess.run([SQLITE,'-batch',':memory:'],input=sql,text=True,capture_output=True)
 av={'code':a.returncode,'stdout':a.stdout,'errors':errors(a.stderr)};bv={'code':b.returncode,'stdout':b.stdout,'errors':errors(b.stderr)};results.append(dict(name=name,sql=sql,lean=av,native=bv,matched=av==bv))
report=dict(cases=len(results),failures=sum(not r['matched'] for r in results),results=results)
open('/tmp/sqleanite-select-stream-register.json','w').write(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
