import SQLeanite.CoreDerivedSQL.Read
open SQLeanite

def inspectPlan : Except String String := do
  let mut state := Core.State.empty
  for source in ["CREATE TABLE src(id INTEGER PRIMARY KEY,n);", "INSERT INTO src VALUES(1,1),(2,2),(3,3);", "CREATE TABLE dst(id INTEGER PRIMARY KEY,n);", "INSERT INTO dst VALUES(10,10);"] do
    let parsed ← CoreTokenGrammar.parseCertified source
    let some statement := parsed.statements[0]? | throw "empty"
    state := (← CoreDerivedSQL.executeStatement state statement source).1
  let sql := "INSERT INTO dst SELECT NULL,last_insert_rowid() FROM(SELECT * FROM src);"
  let parsed ← CoreTokenGrammar.parseCertified sql
  let some statement := parsed.statements[0]? | throw "empty input"
  let .insertSelect target columns query action outputs := statement | throw "bad input"
  let (metadata,prepared) ← CoreDerivedSQL.prepareWithSources [] true 256 state [] query
  let candidate := Statement.insertSelect target columns prepared action outputs
  let names := metadata.database.tables.map (·.schema.name)
  return reprStr (prepared,CoreTriggerProgram.RegisterInput.eligible state candidate,names)
#eval inspectPlan
