import sys,unittest
sys.path.insert(0,'scripts')
from test_pragma_tables import case
from test_subquery_sets import SETUP
class Extra(unittest.TestCase):pass
queries={
 'values':'SELECT 2 IN (VALUES(1),(2),(NULL)),EXISTS(VALUES(1,2));',
 'values_collate':"SELECT 'a' IN (VALUES('A' COLLATE NOCASE));",
 'values_width':'SELECT 1 IN (VALUES(1,2));',
 'zero_validation':'SELECT EXISTS(SELECT missing LIMIT 0);',
 'null_all':'SELECT NULL IN (SELECT NULL),NULL NOT IN (SELECT NULL),1 IN (SELECT NULL);',
 'case_lhs':"SELECT (CASE WHEN 1 THEN '01' END) IN (SELECT n FROM u);",
 'neg_lhs':'SELECT -1 IN (SELECT -n FROM u);',
 'nested_lhs':'SELECT (SELECT n FROM u LIMIT 1) IN (SELECT n FROM t);',
 'exists_lhs':'SELECT EXISTS(SELECT 1) IN (SELECT n FROM t);',
 'notin_nested':'SELECT 3 NOT IN (SELECT n FROM t WHERE n NOT IN (SELECT n FROM u));',
 'rhs_collate_expr':"SELECT 'a' IN (SELECT ('A'||'') COLLATE NOCASE);",
 'rhs_collate_wrapper':"SELECT 'a' IN (SELECT +('A' COLLATE NOCASE));",
 'lhs_collate_wrapper':"SELECT (+('a' COLLATE NOCASE)) IN (SELECT 'A');",
 'scalar_collate':"SELECT (SELECT 'a' COLLATE NOCASE) IN (SELECT 'A');",
 'exists_order_error':'SELECT EXISTS(SELECT n FROM t ORDER BY abs(-9223372036854775808));',
 'exists_having_error':'SELECT EXISTS(SELECT count(*) FROM t HAVING abs(-9223372036854775808));',
 'exists_having_projection':'SELECT EXISTS(SELECT abs(-9223372036854775808)+count(*) AS k FROM t HAVING k);',
 'exists_group_count':'SELECT EXISTS(SELECT sum(n) FROM t GROUP BY n HAVING sum(n)>1 LIMIT 1 OFFSET 1);',
 'exists_distinct_aggregate':'SELECT EXISTS(SELECT count(DISTINCT n) FROM t LIMIT 1 OFFSET 1);',
 'exists_empty_group':'SELECT EXISTS(SELECT n FROM e GROUP BY n);',
 'exists_correlated_aggregate':'SELECT id,EXISTS(SELECT count(*) FROM u WHERE u.n=t.n) FROM t ORDER BY id;',
 'exists_correlated_having':'SELECT id,EXISTS(SELECT count(*) FROM u WHERE u.n=t.n HAVING count(*)>0) FROM t ORDER BY id;',
 'union_all_offset':'SELECT EXISTS(SELECT abs(-9223372036854775808) UNION ALL SELECT abs(-9223372036854775808) LIMIT 1 OFFSET 1);',
 'exists_order_alias':'SELECT EXISTS(SELECT abs(-9223372036854775808) AS a FROM t ORDER BY a);',
 'set_except':'SELECT 2 IN (SELECT n FROM t EXCEPT SELECT n FROM u);',
 'set_intersect':'SELECT 1 IN (SELECT n FROM t INTERSECT SELECT n FROM u);',
 'notin_parens':'SELECT 2 NOT IN (SELECT n FROM t WHERE n=1),NOT (2 IN (SELECT n FROM t WHERE n=1));',
 'exists_alias_shadow':'SELECT EXISTS(SELECT n+1 AS n FROM t WHERE n IS NULL);',
}
for name,sql in queries.items():
 for suffix,mode in [('rollback','--verified-file'),('wal','--verified-wal-file')]:
  setattr(Extra,'test_'+name+'_'+suffix,case(sql,mode,SETUP))
if __name__=='__main__':unittest.main()
