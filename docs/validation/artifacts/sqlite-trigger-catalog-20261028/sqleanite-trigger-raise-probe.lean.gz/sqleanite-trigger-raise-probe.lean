import SQLeanite.CoreTokenGrammar
open SQLeanite
#eval (parse "CREATE TRIGGER gate BEFORE INSERT ON T BEGIN SELECT RAISE(ABORT,'blocked'); END;").map reprStr
#eval (CoreTokenGrammar.parseStatements "CREATE TRIGGER gate BEFORE INSERT ON T BEGIN SELECT RAISE(ABORT,'blocked'); END;").map reprStr
