#!/usr/bin/env python3
"""Native UTF-16 comparison at predicate and correlated-capture boundaries."""
import unittest
from test_utf16_provenance import case
class UTF16Predicates(unittest.TestCase):pass
READS={
 'case_value':"SELECT CASE v WHEN CAST(X'{equivalent}' AS TEXT) THEN 1 ELSE 0 END FROM t;",
 'between_value':"SELECT v BETWEEN CAST(X'{equivalent}' AS TEXT) AND CAST(X'{equivalent}' AS TEXT) FROM t;",
 'between_where':"SELECT id FROM t WHERE v BETWEEN CAST(X'{equivalent}' AS TEXT) AND CAST(X'{equivalent}' AS TEXT);",
 'in_single':"SELECT v IN(CAST(X'{equivalent}' AS TEXT)) FROM t;",
 'in_three':"SELECT v IN(CAST(X'{equivalent}' AS TEXT),'x','y') FROM t;",
 'in_subquery':"SELECT v IN(SELECT CAST(X'{equivalent}' AS TEXT)) FROM t;",
 'outer_scalar':'SELECT hex((SELECT a.v)) FROM t a;',
 'outer_hex':'SELECT (SELECT hex(a.v)) FROM t a;',
}
for enc,pairs in [
 ('UTF-16le',[('00D84100','00D841DC'),('00D8','FDFF'),('FEFF','FDFF'),('4100','4100')]),
 ('UTF-16be',[('D8000041','D800DC41'),('D800','FFFD'),('FFFE','FFFD'),('0041','0041')])]:
 for index,(payload,equivalent) in enumerate(pairs):
  for name,sql in READS.items():
   for suffix,mode in [('rollback','--verified-file'),('wal','--verified-wal-file')]:
    setattr(UTF16Predicates,f'test_{enc.replace("-","_")}_{index}_{name}_{suffix}',case(enc,payload,equivalent,sql,mode))
if __name__=='__main__':unittest.main()
